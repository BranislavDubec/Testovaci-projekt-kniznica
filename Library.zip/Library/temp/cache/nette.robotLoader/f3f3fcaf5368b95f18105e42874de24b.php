<?php
return array (
  0 => 
  array (
    'App\\Bootstrap' => 
    array (
      'file' => 'C:\\Users\\dubec\\Library\\app\\Bootstrap.php',
      'time' => 1614505973,
    ),
    'App\\Presenters\\Error4xxPresenter' => 
    array (
      'file' => 'C:\\Users\\dubec\\Library\\app\\Presenters\\Error4xxPresenter.php',
      'time' => 1614505973,
    ),
    'App\\Presenters\\ErrorPresenter' => 
    array (
      'file' => 'C:\\Users\\dubec\\Library\\app\\Presenters\\ErrorPresenter.php',
      'time' => 1614505973,
    ),
    'App\\Presenters\\HomepagePresenter' => 
    array (
      'file' => 'C:\\Users\\dubec\\Library\\app\\Presenters\\HomepagePresenter.php',
      'time' => 1614619740,
    ),
    'App\\Router\\RouterFactory' => 
    array (
      'file' => 'C:\\Users\\dubec\\Library\\app\\Router\\RouterFactory.php',
      'time' => 1614505974,
    ),
  ),
  1 => 
  array (
    'Nette\\Application\\UI\\ISignalReceiver' => 41,
    'Nette\\Application\\UI\\IStatePersistent' => 38,
    'Nette\\Security\\IResource' => 22,
    'Nette\\Application\\UI\\ITemplate' => 35,
    'Nette\\Application\\UI\\ITemplateFactory' => 32,
    'Nette\\Security\\IRole' => 19,
    'Nette\\Application\\IResponse' => 29,
    'Nette\\Database\\IConventions' => 9,
    'Nette\\Localization\\Nette\\Localization\\ITranslator' => 9,
    'Nette\\Forms\\IFormRenderer' => 6,
    'App\\Presenters\\HomepageTemplate' => 4,
    'Nette\\Forms\\ISubmitterControl' => 3,
    'App\\Presenters\\FalsePresenter' => 3,
  ),
);
